import "./assets/css/main.css";
import anhlogo from "./assets/images/Ten-truong-do-1000x159.png";
import { Outlet, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";

const Layout = () => {
  const [user, setUser] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("user");
    setUser(null);
    navigate("/login");
  };

  return (
    <>
      <style>{`
        /* HEADER */
        .header1 {
          background-color: #3F51B5; 
          color: #FFFFFF;
        }

        .banner1 {
          background-color: #7986CB; 
          color: #FFFFFF;
        }

        .menubar {
          background-color: #5C6BC0; 
          color: #FFFFFF;
        }

        .menubar-left .menu-item {
          color: #FFFFFF;
          margin-right: 20px;
          font-weight: 600;
          text-decoration: none;
        }

        .menubar-left .menu-item:hover {
          color: #FFD54F; 
        }

        .menubar-right .login-link,
        .menubar-right .username {
          color: #FFFFFF;
          font-weight: bold;
        }

        .logout-btn {
          background: #FF8A65; 
          border: none;
          padding: 6px 12px;
          color: white;
          border-radius: 6px;
          cursor: pointer;
          font-weight: bold;
        }

        .logout-btn:hover {
          background: #FF7043; 
          color: #FFFFFF;
        }

        #topleft ul.ul1 li a {
          color: #FFFFFF;
          font-weight: bold;
          text-decoration: none;
        }

        #topleft ul.ul1 li a:hover {
          color: #FFD54F;
        }

        .container {
          background: linear-gradient(135deg, #E8F0FE 0%, #F3F6FB 100%);
          min-height: 80vh;
          padding: 20px;
        }
      `}</style>

      <div className="header1">
        <div className="banner1">
          <div id="topleft">
            <ul className="ul1">
              <li>
                <a href="/#">TRANG CHỦ</a>
              </li>
              <li>
                <a href="/trang1">EGOV</a>
              </li>
              <li>
                <a href="/admin/products">QUẢN TRỊ</a>
              </li>
            </ul>
          </div>
          <div id="logo" className="logo1">
            <img src={anhlogo} width="548" alt="logo" />
          </div>
          <div id="divtimkiem" style={{ width: "300px" }}>
            Phần tìm kiếm
          </div>
        </div>

        <div className="menubar">
          <div className="menubar-left">
            <a href="/menu1" className="menu-item">
              Menu 1
            </a>
            <a href="/menu2" className="menu-item">
              Menu 2
            </a>
            <a href="/menu3" className="menu-item">
              Menu 3
            </a>
          </div>

          <div className="menubar-right">
            {user ? (
              <>
                <span className="username">👤 {user.username}</span>
                <button className="logout-btn" onClick={handleLogout}>
                  Đăng xuất
                </button>
              </>
            ) : (
              <a href="/login" className="login-link">
                Đăng nhập
              </a>
            )}
          </div>
        </div>
      </div>

      <main className="container">
        <Outlet />
      </main>

      <footer></footer>
    </>
  );
};

export default Layout;
